package ca.bcit.comp2601.lab06;

public class MissingFileName extends Exception
{
    public MissingFileName(final String message)
    {
        super(message);
    }
}
