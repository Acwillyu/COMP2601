package ca.bcit.comp2601.lab06;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

/**
 * This class contains the main method that reads from two input files, creates new files, and writes to them.
 * The program takes a single command line argument that specifies the name of the output file.
 * The input files are "firstnames.txt" and "fullnames.txt" located in the "src/in_text_files" directory.
 * The output files are created in the "src/out_text_files" directory.
 * The program reads each line from "firstnames.txt" and creates a new file with the same name in the "src/out_text_files/firstnames" directory.
 * The program then writes the name to the file "src/out_text_files/firstnames/[name].txt" as many times as there are characters in the name.
 * The program then reads each line from "firstnames.txt" and writes the name to the output file if it appears in "fullnames.txt".
 * The output file is created with the name specified in the command line argument.
 * The program throws a MissingFileName exception if no command line argument is provided or if the argument does not end with ".txt".
 * The program throws an InvalidFileName exception if the command line argument is longer than 20 characters or if it does not end with ".txt".
 *
 * @author Ethan Newton, Erik Lagman, William Yu
 * @version 1.0
 */
public class Main {

    private static final int MISSING_FILE_NAME;
    private static final int INVALID_FILE_NAME;
    private static final int FOR_LOOP_INDEX;
    private static final int FOR_LOOP_START;
    private static final int ARGS_INDEX;
    private static final int LINE_SPLIT_INDEX;
    private static final int LINE_SPLIT_QUANTITY;
    private static final int MAX_NAME_LENGTH;

    static {
        MISSING_FILE_NAME   = 1;
        INVALID_FILE_NAME   = 0;
        FOR_LOOP_INDEX      = -1;
        FOR_LOOP_START      = 0;
        ARGS_INDEX          = 0;
        LINE_SPLIT_INDEX    = 0;
        LINE_SPLIT_QUANTITY = 2;
        MAX_NAME_LENGTH     = 20;
    }


    public static void main(final String[] args)
    {
        File       nameFile;
        final File mainFile;
        FileReader reader;
        FileReader reader2;
        FileWriter writer;
        Scanner    scanner;
        Scanner    scanner2;


        try {
            if (args.length != MISSING_FILE_NAME)
            {
                throw new MissingFileName("Missing File Name. Please specify a file name that ends in \".txt\"");
            }

            final String fileName;
            fileName = args[INVALID_FILE_NAME];

            if(!isValidFileName(fileName))
            {
                throw new InvalidFileName("Invalid File Name. Please specify a file name that ends in \".txt\"");
            }
        }
        catch(final MissingFileName e)
        {
            System.out.println(e.getMessage());
        }

        try
        {
            reader  = new FileReader("src/text_files/firstnames.txt");
            scanner = new Scanner(reader);

            for(String line; scanner.hasNextLine(); )
            {
                line = scanner.nextLine();

                nameFile = new File("src/output_text_files/firstnames.txt" + line + ".txt");
                if(nameFile.exists())
                {
                    continue;
                }
                else
                {
                    nameFile.createNewFile();
                }

                writer = new FileWriter("src/output_text_files/firstnames.txt" + line + ".txt");
                for(int i = FOR_LOOP_START; i < line.length() - FOR_LOOP_INDEX; i++)
                {
                    writer.write(line + "\n");
                }
                writer.write(line);
                writer.close();
            }
            scanner.close();

            mainFile = new File("src/output_text_files" + args[ARGS_INDEX]);
            if(mainFile.exists())
            {
                mainFile.delete();
                mainFile.createNewFile();
            }

            reader = new FileReader("src/text_files/firstnames.txt");
            scanner = new Scanner(reader);
            writer = new FileWriter(mainFile);
            for(String line; scanner.hasNextLine(); )
            {
                line = scanner.nextLine();

                reader2 = new FileReader("src/text_files/firstnames.txt");
                scanner2 = new Scanner(reader2);
                for(String line2; scanner2.hasNextLine(); )
                {
                    line2 = scanner2.nextLine();
                    if(!line2.isEmpty())
                    {
                        String[] parts = line2.split("\t", LINE_SPLIT_QUANTITY);

                        System.out.println("Parts length: " + parts.length);

                        if(parts.length > LINE_SPLIT_INDEX && parts[LINE_SPLIT_INDEX].equals(line)){
                            writer.write(line + "\n");
                        }
                    }
                }

            }
            writer.close();
        }
        catch(final IOException e)
        {
            System.out.println(e.getMessage());
        }
    }

    /**
     * Checks if the given file name is valid.
     * A valid file name is not null, has a length less than or equal to 20, and ends with ".txt".
     *
     * @param fileName the file name to be checked
     * @return true if the file name is valid, false otherwise
     */
    private static boolean isValidFileName(final String fileName)
    {
        return fileName != null && fileName.length() <= MAX_NAME_LENGTH && fileName.endsWith(".txt");
    }
}


