package ca.bcit.comp2601.lab06;

public class InvalidFileName extends RuntimeException
{
    public InvalidFileName(final String message)
    {
        super(message);
    }
}

