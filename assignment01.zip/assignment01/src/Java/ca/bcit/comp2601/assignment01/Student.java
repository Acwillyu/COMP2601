package ca.bcit.comp2601.assignment01;
/**
 * The Student class represents a student, extending the Person class and adding a student number.
 * It provides methods to access the student's information, including their student number.
 *
 * @author William Yu
 * @version 1.0
 */
public class Student extends Person {
    private final String studentNumber;
    private static final int ZERO_POINT     = 0;
    private static final int ID_LENGTH_CAP  = 9;
    /**
     * @param born                    The date of birth of the student.
     * @param name                    The name of the student.
     * @param studentNumber           The student number of the student.
     * @throws IllegalPersonException If studentNumber is null, blank, or not exactly 9 characters long.
     */
    public Student(Date born,
                   Name name,
                   String studentNumber)
    {
        super(born, name);

        if (studentNumber == null || studentNumber.isBlank() || studentNumber.length() != ID_LENGTH_CAP)
        {
            throw new IllegalPersonException("bad student number");
        }

        this.studentNumber = studentNumber;
    }
    /**
     * @return The student number of the student.
     */
    public String getStudentNumber()
    {
        return studentNumber;
    }
    /**
     * Overrides the toString method to provide a customized string representation of the student,
     * including their name, student number, birth date, and, if applicable, death date.
     * @return A string representing the student's information.
     */
    @Override
    public String toString()
    {
        String personInfo;
        String namePart;

        personInfo = super.toString();
        namePart= personInfo.split(" was born ")[ZERO_POINT];

        if (isAlive()) {
            return namePart + " (student number: " + studentNumber + ") was born " + getDateOfBirth().getYyyyMmDd() +
                    " and is still alive";
        } else {
            return namePart + " (student number: " + studentNumber + ") was born " + getDateOfBirth().getYyyyMmDd() +
                    " and died " + getDateOfDeath().getYyyyMmDd();
        }
    }


}
