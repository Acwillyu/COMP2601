package ca.bcit.comp2601.assignment01;
/**
 * The Orderable interface defines a contract for classes that can be ordered or sequenced.
 * It specifies methods to retrieve the next and previous elements in a sequence.
 *
 * Implementing classes should provide implementations for the 'next' and 'previous' methods
 * to define the ordering behavior.
 *
 * @author William Yu
 * @version 1.0
 */
public interface Orderable
{
    /**
     * @return The next element in the sequence.
     */
    Orderable next();
    /**
     * @return The previous element in the sequence.
     */
    Orderable previous();
}
