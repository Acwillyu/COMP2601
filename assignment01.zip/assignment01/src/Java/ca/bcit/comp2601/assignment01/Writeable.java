package ca.bcit.comp2601.assignment01;
/**
 * The Writeable interface defines a contract for classes that can write data,
 * specifying a method to print data within a specified range.
 * Implementing classes should provide an implementation for the 'printData' method.
 *
 * This interface is typically used to define behavior for writing data to a destination,
 * with the range specified by 'min' and 'max' parameters.
 *
 * @author William Yu
 * @version 1.0
 */
interface Writeable
{
    /**
     * @param s   The data to be printed.
     * @param min The minimum value of the range.
     * @param max The maximum value of the range.
     */
    public void printData(String s,int min, int max);
}
