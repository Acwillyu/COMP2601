package ca.bcit.comp2601.assignment01;
/**
 * The Teacher class represents a teacher, extending the Person class and adding a specialty.
 * It provides methods to access the teacher's information, including their specialty.
 *
 * @author William Yu
 * @version 1.0
 */
public class Teacher extends Person
{
    private final String specialty;
    private static final int ZERO_POINT = 0;

    /**
     * @param born The date of birth of the teacher.
     * @param name The name of the teacher.
     * @param specialty The specialty of the teacher.
     * @throws IllegalPersonException if specialty is null or blank.
     */

    public Teacher(Date born,
                   Name name,
                   String specialty)
    {
        super(born, name);

        if (specialty == null || specialty.isBlank())
        {
            throw new IllegalPersonException("bad specialty");
        }

        this.specialty = specialty;
    }
    /**
     * @return The specialty of the teacher.
     */
    public String getSpecialty()
    {
        return specialty;
    }
    /**
     * Overrides the toString method to provide a customized string representation of the teacher,
     * including their name, specialty, birth date, and, if applicable, death date.
     *
     * @return A string representing the teacher's information.
     */
    @Override
    public String toString()
    {
        String personInfo;
        String namePart;
        String specialtyPart;

        personInfo = super.toString();
        namePart = personInfo.split(" was born ")[ZERO_POINT];
        specialtyPart = "(specialty: " + getSpecialty() + ")";

        if (isAlive())
        {
            return namePart + " " + specialtyPart + " was born " + getDateOfBirth().getYyyyMmDd() +
                    " and is still alive";
        }
        else
        {
            return namePart + " " + specialtyPart + " was born " + getDateOfBirth().getYyyyMmDd() + " and died "
                    + getDateOfDeath().getYyyyMmDd();
        }
    }


}
