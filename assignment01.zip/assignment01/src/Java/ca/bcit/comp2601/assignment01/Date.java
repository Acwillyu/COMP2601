package  ca.bcit.comp2601.assignment01;

public class Date implements Orderable, Comparable<Date>
{
    private final int day;
    private final int month;
    private final int year;

    private static final int INVALID_DAY_START;
    private static final int INVALID_DAY_FEB_NLY;
    private static final int INVALID_DAY_FEB_LY;
    private static final int INVALID_DAY_SMALL;
    private static final int INVALID_DAY_LARGE;

    private static final int NUM_DAY_FEB_NLY;
    private static final int NUM_DAY_FEB_LY;
    private static final int NUM_DAY_SMALL;
    private static final int NUM_DAY_LARGE;

    private static final int INVALID_MONTH_START;
    private static final int INVALID_MONTH_END;

    private static final int INVALID_YEAR;

    private static final int JANUARY;
    private static final int FEBRUARY;
    private static final int MARCH;
    private static final int APRIL;
    private static final int MAY;
    private static final int JUNE;
    private static final int JULY;
    private static final int AUGUST;
    private static final int SEPTEMBER;
    private static final int OCTOBER;
    private static final int NOVEMBER;
    private static final int DECEMBER;

    private static final int LARGE_EXTRA_DAY_VALUE;
    private static final int MEDIUM_EXTRA_DAY_VALUE;
    private static final int SMALL_EXTRA_DAY_VALUE;
    private static final int EXTRA_DAY_YEAR_ONE;
    private static final int EXTRA_DAY_YEAR_TWO;
    private static final int EXTRA_DAY_YEAR_THREE;
    private static final int EXTRA_DAY_YEAR_THREE_END;
    private static final int EXTRA_DAY_YEAR_FOUR;
    private static final int EXTRA_DAY_YEAR_FIVE;

    private static final int CENTURY;
    private static final int QUARTER;
    private static final int FOUR_QUARTERS;
    private static final int STEP_ONE;
    private static final int STEP_THREE;

    private static final int JANUARY_CODE;
    private static final int FEBRUARY_CODE;
    private static final int MARCH_CODE;
    private static final int APRIL_CODE;
    private static final int MAY_CODE;
    private static final int JUNE_CODE;
    private static final int JULY_CODE;
    private static final int AUGUST_CODE;
    private static final int SEPTEMBER_CODE;
    private static final int OCTOBER_CODE;
    private static final int NOVEMBER_CODE;
    private static final int DECEMBER_CODE;

    private static final int SATURDAY;
    private static final int SUNDAY;
    private static final int MONDAY;
    private static final int TUESDAY;
    private static final int WEDNESDAY;
    private static final int THURSDAY;
    private static final int FRIDAY;

    private static final int NEXT;
    private static final int STAY_POINT;
    private static final int SEVENTH_POINT;

    static
    {
        INVALID_DAY_START   = 0;
        INVALID_DAY_FEB_NLY = 29;
        INVALID_DAY_FEB_LY  = 30;
        INVALID_DAY_SMALL   = 31;
        INVALID_DAY_LARGE   = 32;

        NUM_DAY_FEB_NLY = 28;
        NUM_DAY_FEB_LY  = 29;
        NUM_DAY_SMALL   = 30;
        NUM_DAY_LARGE   = 31;

        INVALID_MONTH_START = 0;
        INVALID_MONTH_END   = 13;

        INVALID_YEAR = 0;

        JANUARY      = 1;
        FEBRUARY     = 2;
        MARCH        = 3;
        APRIL        = 4;
        MAY          = 5;
        JUNE         = 6;
        JULY         = 7;
        AUGUST       = 8;
        SEPTEMBER    = 9;
        OCTOBER      = 10;
        NOVEMBER     = 11;
        DECEMBER     = 12;

        LARGE_EXTRA_DAY_VALUE  = 6;
        MEDIUM_EXTRA_DAY_VALUE = 4;
        SMALL_EXTRA_DAY_VALUE  = 2;

        EXTRA_DAY_YEAR_ONE       = 1600;
        EXTRA_DAY_YEAR_TWO       = 1700;
        EXTRA_DAY_YEAR_THREE     = 1800;
        EXTRA_DAY_YEAR_THREE_END = 1900;
        EXTRA_DAY_YEAR_FOUR      = 2000;
        EXTRA_DAY_YEAR_FIVE      = 2100;

        CENTURY       = 100;
        QUARTER       = 4;
        FOUR_QUARTERS = 400;

        STEP_ONE   = 12;
        STEP_THREE = 4;

        JANUARY_CODE   = 1;
        FEBRUARY_CODE  = 4;
        MARCH_CODE     = 4;
        APRIL_CODE     = 0;
        MAY_CODE       = 2;
        JUNE_CODE      = 5;
        JULY_CODE      = 0;
        AUGUST_CODE    = 3;
        SEPTEMBER_CODE = 6;
        OCTOBER_CODE   = 1;
        NOVEMBER_CODE  = 4;
        DECEMBER_CODE  = 6;

        SATURDAY  = 0;
        SUNDAY    = 1;
        MONDAY    = 2;
        TUESDAY   = 3;
        WEDNESDAY = 4;
        THURSDAY  = 5;
        FRIDAY    = 6;

        NEXT          = 1;
        STAY_POINT    = 0;
        SEVENTH_POINT = 7;

    }

    public Date(final int day,
                final int month,
                final int year)
    {
        if(!isValidDay(day, month, year))
        {
            throw new IllegalArgumentException("invalid day of the month");
        }
        if(!isValidMonth(month))
        {
            throw new IllegalArgumentException("invalid month");
        }
        if(!isValidYear(year))
        {
            throw new IllegalArgumentException("invalid year");
        }
        this.day   = day;
        this.month = month;
        this.year  = year;
    }


    /**
     * @return  New date object representing the previous day
     */
    public Date previous()
    {
        int newDay   = day - NEXT;
        int newMonth = month;
        int newYear  = year;

        if (newDay == STAY_POINT) {
            newMonth -= NEXT;
            if (newMonth == STAY_POINT) {
                newYear -= NEXT;
                newMonth = DECEMBER;
            }
            newDay = getNumberOfDaysPerMonth(newMonth, newYear);
        }

        return new Date(newDay, newMonth, newYear);
    }

    /**
     * @return The next date after the current date
     */
    public Date next()
    {
        int newDay   = day + NEXT;
        int newMonth = month;
        int newYear  = year;

        int maxDays = getNumberOfDaysPerMonth(newMonth, newYear);
        if (newDay > maxDays)
        {
            newDay = NEXT;
            newMonth += NEXT;
            if (newMonth > DECEMBER)
            {
                newYear += NEXT;
                newMonth = NEXT;
            }
        }


        return new Date(newDay, newMonth, newYear);
    }

    /**
     * @param day   The day to check
     * @param month The month to check
     * @param year  The year to check
     * @return      True if the day is valid, false otherwise
     */
    private boolean isValidDay(final int day,
                               final int month,
                               final int year)
    {
        if(day < INVALID_DAY_START)
        {
            return false;
        }
        if(day > INVALID_DAY_LARGE)
        {
            return false;
        }
        if(day > INVALID_DAY_FEB_LY && month == FEBRUARY && isLeapYear(year))
        {
            return false;
        }
        if(day >= INVALID_DAY_FEB_NLY && month == FEBRUARY && !isLeapYear(year))
        {
            return false;
        }
        if(day > INVALID_DAY_SMALL && isSmallMonth(month))
        {
            return false;
        }
        return true;
    }

    /**
     * @param year the year to check
     * @return true if the year is a leap year, false otherwise
     */
    private boolean isLeapYear(final int year)
    {
        if(year % QUARTER == STAY_POINT)
        {
            if(year % CENTURY != STAY_POINT)
            {
                return true;
            }
            else
            {
                return year % FOUR_QUARTERS == STAY_POINT;
            }
        }
        else
        {
            return false;
        }
    }

    /**
     * @param month the month to check
     * @return true if the month is a small month, false otherwise
     */
    private boolean isSmallMonth(final int month)
    {
        if(month == APRIL     ||
           month == JUNE      ||
           month == SEPTEMBER ||
           month == NOVEMBER)
        {
            return true;
        }
        return false;
    }

    /**
     * @param month the month to check
     * @return true if the month is valid, false otherwise
     */
    private boolean isValidMonth(final int month)
    {
        if(month <= INVALID_MONTH_START)
        {
            return false;
        }
        if(month >= INVALID_MONTH_END)
        {
            return false;
        }
        return true;
    }

    /**
     * @param year The year to check
     * @return True if the year is valid, otherwise it's false
     */
    private boolean isValidYear(final int year)
    {
        if(year <= INVALID_YEAR)
        {
            return false;
        }
        return true;
    }

    /**
     * @return the day of the month represented by this Date object.
     */
    public int getDay()
    {
        return day;
    }

    /**
     * @return the month of this Date object
     */
    public int getMonth()
    {
        return month;
    }

    /**
     * @return the year of this Date object
     */
    public int getYear()
    {
        return year;
    }

    /**
     * @return the date in the format of "yyyy-MM-dd"
     */
    public String getYyyyMmDd()
    {
        return String.format("%04d-%02d-%02d", year, month, day);
    }

    /**
     * @return the string representation of the date
     */
    @Override
    public String toString()
    {
        return getYyyyMmDd();
    }

    /**
     * @param  d the Date object to be compared
     * @return -1 if this Date is less than the given Date, 0 if they are equal, and 1
     * if this Date is greater than the given Date
     */
    @Override
    public int compareTo(Date d)
    {
        if(year < d.getYear())
        {
            return -NEXT;
        }
        if(year > d.getYear())
        {
            return NEXT;
        }
        if(month < d.getMonth())
        {
            return -NEXT;
        }
        if(month > d.getMonth())
        {
            return NEXT;
        }
        if(day < d.getDay())
        {
            return -NEXT;
        }
        if(day > d.getDay())
        {
            return NEXT;
        }
        return STAY_POINT;
    }

    /**
     * @return a String representing the day of the week for the current date.
     * If the date is invalid, returns "invalid".
     */
    public String getDayOfTheWeek()
    {
        final int day   = getDay();
        final int month = getMonth();
        final int year  = getYear();

        final int step0;
        final int step1;
        final int step2;
        final int step3;
        final int step4;
        final int step5;
        final int step6;
        final int step7;

        step0 = getExtraDayValue(year);
        step1 = (year % CENTURY) / STEP_ONE;
        step2 = (year % CENTURY) - (step1 * STEP_ONE);
        step3 = step2 / STEP_THREE;
        step4 = day;
        step5 = getMonthCode(month);
        step6 = step0 + step1 + step2 + step3 + step4 + step5;
        step7 = step6 % SEVENTH_POINT;

        if(step7 == SATURDAY)
        {
            return "Saturday";
        } else if(step7 == SUNDAY)
        {
            return "Sunday";
        } else if(step7 == MONDAY)
        {
            return "Monday";
        } else if(step7 == TUESDAY)
        {
            return "Tuesday";
        } else if(step7 == WEDNESDAY)
        {
            return "Wednesday";
        } else if(step7 == THURSDAY)
        {
            return "Thursday";
        } else if(step7 == FRIDAY)
        {
            return "Friday";
        }
        return "invalid";
    }

    /**
     * @param year The year to calculate the extra day value
     * @return The extra day value for the given year
     */
    private int getExtraDayValue(final int year)
    {
        if (isLeapYear(year) && month == JANUARY || month == FEBRUARY)
        {
            return LARGE_EXTRA_DAY_VALUE;
        }
        else if (year >= EXTRA_DAY_YEAR_ONE && year < EXTRA_DAY_YEAR_TWO)
        {
            return LARGE_EXTRA_DAY_VALUE;
        }
        else if (year >= EXTRA_DAY_YEAR_TWO && year < EXTRA_DAY_YEAR_THREE)
        {
            return MEDIUM_EXTRA_DAY_VALUE;
        }
        else if (year >= EXTRA_DAY_YEAR_THREE && year < EXTRA_DAY_YEAR_THREE_END)
        {
            return SMALL_EXTRA_DAY_VALUE;
        }
        else if (year >= EXTRA_DAY_YEAR_FOUR && year < EXTRA_DAY_YEAR_FIVE)
        {
            return LARGE_EXTRA_DAY_VALUE;
        }
        else if (year >= EXTRA_DAY_YEAR_FIVE)
        {
            return MEDIUM_EXTRA_DAY_VALUE;
        }
        else
        {
            return STAY_POINT;
        }
    }

    /**
     * @param month The month to get the code
     * @return The code for the given month
     */
    private int getMonthCode(final int month)
    {
        if(month == JANUARY)
        {
            return JANUARY_CODE;
        }
        else if(month == FEBRUARY)
        {
            return FEBRUARY_CODE;
        }
        else if(month == MARCH)
        {
            return MARCH_CODE;
        }
        else if(month == APRIL)
        {
            return APRIL_CODE;
        }
        else if(month == MAY)
        {
            return MAY_CODE;
        }
        else if(month == JUNE)
        {
            return JUNE_CODE;
        }
        else if(month == JULY)
        {
            return JULY_CODE;
        }
        else if(month == AUGUST)
        {
            return AUGUST_CODE;
        }
        else if(month == SEPTEMBER)
        {
            return SEPTEMBER_CODE;
        }
        else if(month == OCTOBER)
        {
            return OCTOBER_CODE;
        }
        else if(month == NOVEMBER)
        {
            return NOVEMBER_CODE;
        }
        else if(month == DECEMBER)
        {
            return DECEMBER_CODE;
        }
        return STAY_POINT;
    }

    /**
     * @param month The month for which to determine the number of days
     * @param year The year for which to determine the number of days
     * @return The number of days in the given month for the given year
     */
    private int getNumberOfDaysPerMonth(int month, int year)
    {
        if(month == FEBRUARY && isLeapYear(year))
        {
            return NUM_DAY_FEB_LY;
        }
        if(month == FEBRUARY && !isLeapYear(year))
        {
            return NUM_DAY_FEB_NLY;
        }
        if(isSmallMonth(month))
        {
            return NUM_DAY_SMALL;
        }
        return NUM_DAY_LARGE;
    }
}
