package ca.bcit.comp2601.assignment01;
/**
 * Name class represents a person's first and last name.
 * Provides methods to get a name from eg. tIgER wOOds to Tiger Woods.
 * Gets initials of names.
 * @author William Yu
 * @version 1.0
 */
public class Name{
    private final String first;
    private final String last;
    private static final int START_POINT;
    private static final int SECOND_POINT;

    static
    {
        START_POINT  = 0;
        SECOND_POINT = 1;
    }


    /**
     * @param first First name of person
     * @param last  Last name of person
     */
    public Name(final String first,
                final String last)
    {
        if (first == null || first.isBlank()) {
            throw new IllegalArgumentException("invalid first name");
        }
        if (last == null || last.isBlank()) {
            throw new IllegalArgumentException("invalid last name");
        }
        this.first = first;
        this.last = last;
    }

    /**
     * @return Formatted full name
     */
    public String getPrettyName()
    {
        String prettyFirst;
        String prettyLast;

        prettyFirst = first.substring(START_POINT,SECOND_POINT).toUpperCase()
                    + first.substring(SECOND_POINT).toLowerCase();

        prettyLast = last.substring(START_POINT,SECOND_POINT).toUpperCase()
                   + last.substring(SECOND_POINT).toLowerCase();

        return prettyFirst + " " + prettyLast;
    }

    /**
     * @return Initials in the "A.B." format. A is initial of first name, B is initial of last.
     */
    public String getInitials()
    {
        return first.substring(START_POINT, SECOND_POINT).toUpperCase() + "." +
                last.substring(START_POINT, SECOND_POINT).toUpperCase() + ".";
    }

}
