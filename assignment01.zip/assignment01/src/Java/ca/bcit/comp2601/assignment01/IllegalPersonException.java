package ca.bcit.comp2601.assignment01;
/**
 * The IllegalPersonException is a custom exception class that extends the RuntimeException class.
 * It is used to indicate exceptions related to illegal or invalid person-related data or operations.
 *
 * This exception can be thrown with a custom error message when illegal conditions are encountered.
 *
 * @author William Yu
 * @version 1.0
 */
public class IllegalPersonException extends RuntimeException
{
    /**
     * @param message The error message describing the reason for the exception.
     */
    public IllegalPersonException(String message)
    {
        super(message);
    }
}
