package ca.bcit.comp2601.assignment01;
import java.util.ArrayList;
import java.util.List;
import java.io.FileWriter;
import java.io.IOException;
/**
 * The School class represents a school's roster of people, including students and teachers.
 * It provides methods for registering people, printing the roster, printing ages and years,
 * and saving details to a file.
 *
 * This class uses the Writeable interface for printing ages and years and the CURRENT_YEAR constant
 * for handling current year information.
 *
 * @author William Yu
 * @version 1.0
 */
public class School
{
    private static final int CURRENT_YEAR = 2022;
    private final List<Person> roster = new ArrayList<>();

    /**
     * Registers a person into the school's roster.
     * @param p The person to be registered.
     * @throws IllegalPersonException if the provided person is null.
     */
    public void register(Person p)
    {
        if (p == null)
        {
            throw new IllegalPersonException("cannot register a non-person");
        }
        roster.add(p);
    }
    /**
     * Prints the roster of people, including their details such as name, birth date, and, if applicable, death date.
     */
    public void printRoster()
    {
        for (Person person : roster)
        {
            System.out.println(person);
        }
    }
    /**
     * Prints the ages and years of the registered people using a provided Writeable implementation.
     */
    public void printAgesAndYears() {
        Writeable writeable;
        writeable = (name, yearBorn, maxYear) ->
        {
            System.out.println(name);
        };

        for (Person person : roster)
        {
            String fullName;
            int yearBorn;
            int maxYear;

            fullName = person.getName().getPrettyName();
            yearBorn = person.getDateOfBirth().getYear();
            maxYear = getMaxYear(person);

            for (int year = yearBorn; year <= maxYear; year++) {
                int age = year - yearBorn;
                String name = fullName + ": " + year + " (age " + age + ")";
                writeable.printData(name, yearBorn, maxYear);
            }
        }
    }
    /**
     * @param person The person for whom to determine the maximum year.
     * @return The maximum year (either the current year or the year of death if applicable).
     */
    private int getMaxYear(Person person)
    {
        if (person.isAlive())
        {
            return School.CURRENT_YEAR;
        } else
        {
            return person.getDateOfDeath().getYear();
        }
    }
    /**
     * Saves the details of registered people to a text file named "people.txt".
     */
    public void saveDetails()
    {
        FileWriter writer;
        try
        {
            writer = new FileWriter("people.txt");
            for (Person person : roster)
            {
                String fullName;
                String initials;
                String dayOfTheWeek;
                String deathInfo;
                String output;

                fullName = person.getName().getPrettyName();
                initials = person.getName().getInitials();
                dayOfTheWeek= person.getDateOfBirth().getDayOfTheWeek();

                deathInfo = "";

                if (!person.isAlive())
                {
                    deathInfo = " and died on " + person.getDateOfDeath().getDayOfTheWeek() + " "
                            + person.getDateOfDeath().getYyyyMmDd();
                }

                output =  fullName + " (" + initials + ") was born on " + dayOfTheWeek + " "
                        + person.getDateOfBirth().getYyyyMmDd() + deathInfo + ".";


                writer.write(output + System.lineSeparator());
            }
            writer.close();
        } catch (final IOException e)
        {
            System.out.println(e.getMessage());
        }
    }

}
