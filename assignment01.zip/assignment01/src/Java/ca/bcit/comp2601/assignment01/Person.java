package ca.bcit.comp2601.assignment01;
/**
 * The Person class represents an individual with a name and date of birth.
 * It provides methods to handle a person's information, including their name, date of birth,
 * and date of death (if applicable).
 *
 * This class implements the Comparable interface, allowing comparison of individuals based on
 * their birth dates.
 *
 * @author William Yu
 * @version 1.0
 */
public class Person implements Comparable<Person>
{
    public Date born;
    public Date died;
    public final Name name;
    /**
     * @param born The date of birth of the person.
     * @param name The name of the person.
     * @throws IllegalPersonException if born or name is null.
     */
    public Person(Date born,
                  Name name)
    {
        if (born == null)
        {
            throw new IllegalPersonException("invalid date of birth");
        }
        if (name == null)
        {
            throw new IllegalPersonException("invalid name");
        }
        this.born = born;
        this.name = name;
    }
    /**
     * @return The name of the person.
     */
    public Name getName()
    {
        return name;
    }
    /**
     * @param dateOfDeath The date of death of the person.
     */
    public void die(Date dateOfDeath)
    {
        died = dateOfDeath;
    }
    /**
     * @return true if the person is alive, false if the person is deceased.
     */
    public boolean isAlive()
    {
        return died == null;
    }
    /**
     * @param other The other Person to compare to.
     * @return A negative integer, zero, or a positive integer if this person's birth date
     * is less than, equal to, or greater than the other person's birth date, respectively.
     */
    @Override
    public int compareTo(Person other)
    {
        return born.compareTo(other.born);
    }
    /**
     * @return A string representing the person's information.
     */
    @Override
    public String toString() {
        if (isAlive()) {
            return name.getPrettyName() + " was born " + born.getYyyyMmDd() + " and is still alive";
        } else {
            return name.getPrettyName() + " was born " + born.getYyyyMmDd() + " and died " + died.getYyyyMmDd();
        }
    }
    /**
     * @return The date of birth of the person.
     */
    public Date getDateOfBirth()
    {
        return born;
    }
    /**
     * @return The date of death of the person, or null if the person is alive.
     */
    public Date getDateOfDeath()
    {
        return died;
    }
}

