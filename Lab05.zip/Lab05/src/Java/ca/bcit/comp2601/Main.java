package ca.bcit.comp2601;
import java.util.List;
/**
 * This class represents a program that takes in command line arguments and performs operations on a dictionary of words.
 * The operations include concatenating the first n words in the dictionary, repeating each word in the dictionary n times,
 * returning the nth word in the dictionary, and reversing the order of the first n words in the dictionary.
 * The program uses a functional interface to perform the operations on the dictionary.
 * The dictionary is represented by an instance of the Dictionary class.
 * The program takes in two command line arguments: the operation to perform and the argument for the operation (if applicable).
 * The program then prints the result of the operation to the console.
 * Finally, the program prints all the words in the dictionary to the console.
 *
 * @author William Yu, Erik Lagman, Ethan Newton
 * @version 1.0
 */
public class Main {
    private static final int LOOP_START;
    private static final int REVERSE_INDEX;
    private static final int INITIAL_ARGUMENT;
    private static final int SECONDARY_ARGUMENT;
    private static final String CONCAT;
    private static final String REPEAT;
    private static final String NTH;
    private static final String REVERSE;
    private static final int    SECOND = 0;
    private static final int    SECOND_LENGTH = 2;


    static
    {
        LOOP_START          = 0;
        REVERSE_INDEX       = 1;
        INITIAL_ARGUMENT    = 0;
        SECONDARY_ARGUMENT  = 1;
        CONCAT              = "concat";
        REPEAT              = "repeat";
        NTH                 = "nth";
        REVERSE             = "reverse";
    }

    public static void main(final String[] args)
    {
        Dictionary dictionary = new Dictionary();

        Wordable wordy = (s, n) ->
        {
            StringBuilder sb;
            sb = new StringBuilder();

            List<String> wordList = dictionary.getWordList();

            int size = wordList.size();

            if (CONCAT.equals(s)) {
                for (int i = LOOP_START; i < n && i < size; i++)
                {
                    sb.append(wordList.get(i));
                }
            }

            if (REPEAT.equals(s)) {
                for (int i = LOOP_START; i < size; i++)
                {
                    for (int j = LOOP_START; j < n; j++)
                    {
                        sb.append(wordList.get(i));
                    }
                }
            }

            if (NTH.equals(s)) {
                if (n >= LOOP_START && n < size) {
                    sb.append(wordList.get(n));
                }
            }

            if (REVERSE.equals(s))
            {
                for (int i = LOOP_START; i < n && i < size; i++)
                {
                    sb.append(new StringBuilder(wordList.get(size - REVERSE_INDEX - i)).reverse());
                }
            }

            return sb.toString();
        };

        int secondary = SECOND;

        if (args.length > SECOND_LENGTH)
        {
            secondary = Integer.parseInt(args[SECONDARY_ARGUMENT]);
        }

        if (args.length > SECONDARY_ARGUMENT)
        {
            String operation = args[INITIAL_ARGUMENT];

            if (CONCAT.equalsIgnoreCase(operation))
            {
                System.out.println(dictionary.getWords(CONCAT, secondary, wordy));
            } else if (REPEAT.equalsIgnoreCase(operation))
            {
                System.out.println(dictionary.getWords(REPEAT, secondary, wordy));
            } else if (NTH.equalsIgnoreCase(operation))
            {
                System.out.println(dictionary.getWords(NTH, secondary, wordy));
            } else if (REVERSE.equalsIgnoreCase(operation))
            {
                System.out.println(dictionary.getWords(REVERSE, secondary, wordy));
            } else
            {
                System.out.println("Invalid operation");
            }
        } else
        {
            System.out.println("Invalid arguments");
        }

        dictionary.getWordList().forEach(System.out::println);
    }
}
