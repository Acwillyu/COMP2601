package ca.bcit.comp2601;

/**
 * The Wordable interface provides a method for creating a string by repeating a given string a
 * specified number of times.
 *
 * @author William Yu, Erik Lagman, Ethan Newton
 * @version 1.0
 */


public interface Wordable {
    /**
     * @param s the string to repeat
     * @param n the number of times to repeat the string
     * @return the new string created by repeating the given string n times
     */
    String createString(String s, int n);
}
