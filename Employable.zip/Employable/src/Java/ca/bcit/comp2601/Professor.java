package ca.bcit.comp2601;
import java.util.Objects;
/**
 * Professor that is also under employee. Extension of Employee class. Implements comparable to compare
 * professors teaching major to other professors.
 * @author William Yu, Ethan Newton, Erik Legman
 * @version 1.0
 */
public class Professor extends Employee implements Comparable<Professor>
{
    // Overtime rate
    public static final double OVERTIME_RATE = 2.0;
    // Hash return
    public static final int    HASH_RETURN   = 0;
    // Teaching major of professor
    public String              teachingMajor;

    /**
     * @param name           Name of professor.
     * @param teachingMajor  What the professor teaches.
     */
    public Professor(String name,
                     String teachingMajor)
    {
        super(name);
        this.teachingMajor = teachingMajor;
    }

    @Override
    public double getOverTimePayRate()
    {
        return OVERTIME_RATE;
    }

    @Override
    public String getDressCode()
    {
        return "fancy";
    }

    @Override
    public boolean isPaidSalary()
    {
        return true;
    }

    @Override
    public boolean postSecondaryEducationRequired()
    {
        return true;
    }

    @Override
    public String getWorkVerb()
    {
        return "teach";
    }

    @Override
    public int compareTo(Professor other)
    {
        return this.teachingMajor.compareTo(other.teachingMajor);
    }

    @Override
    public boolean equals(Object that)
    {
        if (this == that) return true;
        if (that == null || getClass() != that.getClass()) return false;

        Professor thatProfessor;
        thatProfessor = (Professor) that;

        return Objects.equals(teachingMajor, thatProfessor.teachingMajor);
    }

    @Override
    public int hashCode()
    {
        return HASH_RETURN;
    }
}
