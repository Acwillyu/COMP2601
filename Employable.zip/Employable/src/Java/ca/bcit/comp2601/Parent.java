package ca.bcit.comp2601;
/**
 * Parent that is also under employee. Class is an extension of Employee class. Implements comparable
 * to compare the hours spent with kids per week.
 * @author William Yu, Ethan Newton, Erik Legman
 * @version 1.0
 */
public class Parent extends Employee implements Comparable<Parent>
{
    // Overtime rate is always -2.0
    public static final double OVERTIME_RATE = -2.0;
    // Hash code return
    public static int          HASH_RETURN   = 0;
    // Number of hours spent per week with kids
    public int numberOfHoursSpentPerWeekWithKids;

    /**
     * @param name                               Name of the parent.
     * @param numberOfHoursSpentPerWeekWithKids  Number of hours spent with kids per week.
     */
    public Parent(String name,
                  int numberOfHoursSpentPerWeekWithKids)
    {
        super(name);
        this.numberOfHoursSpentPerWeekWithKids = numberOfHoursSpentPerWeekWithKids;

    }
    @Override
    public double getOverTimePayRate()
    {
        return OVERTIME_RATE;
    }

    @Override
    public String getDressCode()
    {
        return "anything";
    }

    @Override
    public boolean isPaidSalary()
    {
        return false;
    }

    @Override
    public boolean postSecondaryEducationRequired()
    {
        return false;
    }

    @Override
    public String getWorkVerb()
    {
        return "care";
    }

    @Override
    public boolean getsPaid()
    {
        return false;
    }

    @Override
    public int compareTo(Parent other)
    {
        return Integer.compare(this.numberOfHoursSpentPerWeekWithKids, other.numberOfHoursSpentPerWeekWithKids);
    }


    @Override
    public boolean equals(Object that)
    {
        if (this == that) return true;
        if (that == null || getClass() != that.getClass()) return false;

        Parent thatParent;
        thatParent = (Parent) that;
        return numberOfHoursSpentPerWeekWithKids == thatParent.numberOfHoursSpentPerWeekWithKids;
    }

    @Override
    public int hashCode()
    {
        return HASH_RETURN;
    }
}
