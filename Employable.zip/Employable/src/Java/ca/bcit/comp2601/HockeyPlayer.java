package ca.bcit.comp2601;
/**
 * HockeyPlayer that is also an employee. Extension of Employee class and implements comparable for
 * comparing hockey players based on goals.
 * @author William Yu, Ethan Newton, Erik Legman
 * @version 1.0
 */
public class HockeyPlayer extends Employee implements Comparable<HockeyPlayer>
{
    // Always 0 because they don't get overtime
    public static final double OVERTIME_RATE = 0;
    // Hash code return
    public static final int    HASH_RETURN   = 0;
    // Number of goals scored by hockey player
    public int                 numberOfGoals;

    /**
     * @param name           Name of hockey player.
     * @param numberOfGoals  Number of goals by hockey player.
     */
    public HockeyPlayer(String name,
                        int numberOfGoals)
    {
        super(name);
        this.numberOfGoals = numberOfGoals;
    }

    @Override
    public double getOverTimePayRate()
    {
        return OVERTIME_RATE;
    }

    @Override
    public String getDressCode()
    {
        return "jersey";
    }

    @Override
    public boolean isPaidSalary()
    {
        return true;
    }

    @Override
    public boolean postSecondaryEducationRequired()
    {
        return false;
    }

    @Override
    public String getWorkVerb()
    {
        return "play";
    }

    @Override
    public int compareTo(HockeyPlayer other)
    {
        return Integer.compare(this.numberOfGoals, other.numberOfGoals);
    }

    @Override
    public boolean equals(Object that)
    {
        if (this == that) return true;
        if (that == null || getClass() != that.getClass()) return false;

        HockeyPlayer thatPlayer;
        thatPlayer = (HockeyPlayer) that;

        return numberOfGoals == thatPlayer.numberOfGoals;

    }

    @Override
    public int hashCode()
    {
        return HASH_RETURN;
    }

}
