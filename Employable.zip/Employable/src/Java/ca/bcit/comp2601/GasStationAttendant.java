package ca.bcit.comp2601;
/**
 * Gas station attendant that is also under employee. Extension of Employee. Implements comparable to compare
 * the amount of money stolen by gas station attendants.
 */
public class GasStationAttendant extends Employee implements Comparable<GasStationAttendant>
{
    //Gas station attendant overtime rate.
    public static final double OVERTIME_RATE = 1.5;
    // Hash return
    public static final int    HASH_RETURN   = 0;
    //If gas attendants stealing is equal, it will be 0 and therefore be true.
    public static final int    STOLEN_MONEY  = 0;
    //Amount of money stolen per day.
    public double numberOfDollarsStolenPerDay;

    /**
     * @param name                         Name of gas attendant.
     * @param numberOfDollarsStolenPerDay  Amount of dollars stolen per day by gas attendant.
     */
    public GasStationAttendant(String name,
                               double numberOfDollarsStolenPerDay)
    {
        super(name);
        this.numberOfDollarsStolenPerDay = numberOfDollarsStolenPerDay;
    }


    @Override
    public double getOverTimePayRate()
    {
        return OVERTIME_RATE;
    }

    @Override
    public String getDressCode()
    {
        return "uniform";
    }

    @Override
    public boolean isPaidSalary()
    {
        return false;
    }

    @Override
    public boolean postSecondaryEducationRequired()
    {
        return false;
    }

    @Override
    public String getWorkVerb()
    {
        return "pump";
    }

    @Override
    public int compareTo(GasStationAttendant other)
    {
        return Double.compare(this.numberOfDollarsStolenPerDay, other.numberOfDollarsStolenPerDay);
    }

    @Override
    public boolean equals(Object that) {
        if (this == that) return true;
        if (that == null || getClass() != that.getClass()) return false;

        GasStationAttendant thatAttendant;
        thatAttendant = (GasStationAttendant) that;

        return Double.compare(thatAttendant.numberOfDollarsStolenPerDay, numberOfDollarsStolenPerDay) == STOLEN_MONEY;
    }

    @Override
    public int hashCode()
    {
        return HASH_RETURN;
    }

}
