package ca.bcit.comp2601;
/**
 * Represents the type of employee.
 * @author William Yu, Ethan Newton, Erik Legman
 * @version 1.0
 */
public abstract class Employee implements Employable
{
    // Name of employee
    private final String name;

    /**
     * @param name Name of employee.
     */
    public Employee(String name)
    {
        this.name = name;
    }

    /**
     * @return Overtime rate for employee.
     */
    public abstract double getOverTimePayRate();

    /**
     * @return Name of the employee.
     */
    public String getName()
    {
        return name;
    }

}
