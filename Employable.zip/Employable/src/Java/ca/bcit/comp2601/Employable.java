package ca.bcit.comp2601;
/**
 * Interface for employee.
 * @author  William Yu, Ethan Newton, Erik Legman
 * @version 1.0
 */
interface Employable
{
    /**
     * Uniform or attire.
     */
    public String  getDressCode();

    /**
     * Salary paid.
     */
    public boolean isPaidSalary();

    /**
     * Post secondary education if required.
     */
    public boolean postSecondaryEducationRequired();

    /**
     * Work term for their job.
     */
    public String  getWorkVerb();

    /**
     * @return Always returns true that they get paid.
     */
    default public boolean getsPaid()
    {
        return true;
    }

}
