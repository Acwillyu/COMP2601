package ca.bcit.comp2601;
import java.util.ArrayList;
import java.util.Collections;

public class Employees
{
    private final ArrayList<HockeyPlayer> hockeyPlayers;
    private final ArrayList<Professor> professors;
    private final ArrayList<Parent> parents;
    private final ArrayList<GasStationAttendant> gasStationAttendants;
    private final ArrayList<Employee> employeeList;

    public static final int EMPLOYEE_LIST_SIZE                  = 20;
    public static final int GRETZKY_GOALS                       = 894;
    public static final int WHO_EVER_GOALS                      = 0;
    public static final int BRENT_GRETZKY_GOALS                 = 1;
    public static final int PAVEL_BURE_GOALS                    = 437;
    public static final int JASON_HARRISON_GOALS                = 0;
    public static final int TIGER_WOODS_HOURS                   = 1;
    public static final int SUPER_MOM_HOURS                     = 168;
    public static final int LAZY_LARRY_HOURS                    = 20;
    public static final int EX_HAUSTED_HOURS                    = 168;
    public static final int SUPER_DAD_HOURS                     = 167;
    public static final double JOE_SMITH_STOLEN_MONEY           = 10.0;
    public static final double TONY_BALONEY_STOLEN_MONEY        = 100.0;
    public static final double BENJAMIN_FRANKLIN_STOLEN_MONEY   = 100.0;
    public static final double MARY_FAIRY_STOLEN_MONEY          = 101.0;
    public static final double BEE_SEE_STOLEN_MONEY             = 1.0;
    public static final int    LIST_SIZE                        = 0;
    public static final int    J_LIST_SIZE                      = 1;

    /**
     * Array list of hockeyPlayers, professors, parents, gasStationAttendants and employee.
     */
    public Employees()
    {
        hockeyPlayers        = new ArrayList<>();
        professors           = new ArrayList<>();
        parents              = new ArrayList<>();
        gasStationAttendants = new ArrayList<>();
        employeeList         = new ArrayList<>(EMPLOYEE_LIST_SIZE);

        // Adding HockeyPlayers
        employeeList.add(new HockeyPlayer("Wayne Gretzky", GRETZKY_GOALS));
        employeeList.add(new HockeyPlayer("Who Ever", WHO_EVER_GOALS));
        employeeList.add(new HockeyPlayer("Brent Gretzky", BRENT_GRETZKY_GOALS));
        employeeList.add(new HockeyPlayer("Pavel Bure", PAVEL_BURE_GOALS));
        employeeList.add(new HockeyPlayer("Jason Harrison", JASON_HARRISON_GOALS));

        // Adding Professors
        employeeList.add(new Professor("Albert Einstein", "Physics"));
        employeeList.add(new Professor("Jason Harrison", "Computer Systems"));
        employeeList.add(new Professor("Richard Feynman", "Physics"));
        employeeList.add(new Professor("BCIT Instructor", "Computer Systems"));
        employeeList.add(new Professor("Kurt Godel", "Logic"));

        // Adding Parents
        employeeList.add(new Parent("Tiger Woods", TIGER_WOODS_HOURS));
        employeeList.add(new Parent("Super Mom", SUPER_MOM_HOURS));
        employeeList.add(new Parent("Lazy Larry", LAZY_LARRY_HOURS));
        employeeList.add(new Parent("Ex Hausted", EX_HAUSTED_HOURS));
        employeeList.add(new Parent("Super Dad", SUPER_DAD_HOURS));

        // Adding GasStationAttendants
        employeeList.add(new GasStationAttendant("Joe Smith", JOE_SMITH_STOLEN_MONEY));
        employeeList.add(new GasStationAttendant("Tony Baloney", TONY_BALONEY_STOLEN_MONEY));
        employeeList.add(new GasStationAttendant("Benjamin Franklin", BENJAMIN_FRANKLIN_STOLEN_MONEY));
        employeeList.add(new GasStationAttendant("Mary Fairy", MARY_FAIRY_STOLEN_MONEY));
        employeeList.add(new GasStationAttendant("Bee See", BEE_SEE_STOLEN_MONEY));

        //Adds employees to their respective arrayList.
        for (Employee employee : employeeList)
        {
            if(employee instanceof HockeyPlayer)
            {
                hockeyPlayers.add((HockeyPlayer) employee);
            }
            else if(employee instanceof Professor)
            {
                professors.add((Professor) employee);
            }
            else if(employee instanceof Parent)
            {
                parents.add((Parent) employee);
            }
            else if(employee instanceof GasStationAttendant)
            {
                gasStationAttendants.add((GasStationAttendant) employee);
            }
        }

        //Sorts each arrayList
        Collections.sort(hockeyPlayers);
        Collections.sort(professors);
        Collections.sort(parents);
        Collections.sort(gasStationAttendants);
    }

    /**
     * Displays all true comparisons. Eg. If two hockeyPlayers have the same amount of goals.
     */
    public void displayEqualObjects()
    {
        System.out.println("Hockey Players with equal goals:");
        displayEqualObjects(hockeyPlayers);

        System.out.println("\nProfessors in the same field:");
        displayEqualObjects(professors);

        System.out.println("\nParents with equal hours:");
        displayEqualObjects(parents);

        System.out.println("\nGas Station Attendants who stole the same amount of money:");
        displayEqualObjects(gasStationAttendants);
    }

    /**
     * Compares and displays pairs of equal objects within the provided list. For these lists, hockeyPlayer compares
     * goals, professor compares teaching majors, parents compare equal hours attended with the kids per week and
     * gas station attendants compare who stole the same amount of money.
     * @param list Lists extension of the Employee class or implement the Employee interface.
     * @param <T>  ArrayList of objects being compared.
     */
    private <T extends Employee> void displayEqualObjects(ArrayList<T> list)
    {
        for (int i = LIST_SIZE; i < list.size(); i++)
        {
            for (int j = i + J_LIST_SIZE; j < list.size(); j++)
            {
                if (list.get(i).equals(list.get(j)))
                {
                    System.out.println(list.get(i).getName() + " and " + list.get(j).getName());
                }
            }
        }
    }

    /**
     * @return ArrayList of employees.
     */
    public ArrayList<Employee> getEmployeeList()
    {
        return employeeList;
    }

    /**
     * Calls the displayEqualObjects method to find and display pairs of equal objects.
     * @param args Command line argument
     */
    public static void main(final String[] args)
    {
        Employees  employees;
        employees = new Employees();
        employees.displayEqualObjects();
    }


}

