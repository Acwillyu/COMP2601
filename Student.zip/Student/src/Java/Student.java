public class Student
{
    private final String studentId;

    public Student(String studentId)
    {
        this.studentId = studentId;
    }

    public String getStudentId()
    {
        return studentId;
    }

    @Override
    public boolean equals(final Object students)
    {
        if (this == students)
        {
            return true;
        }
        if (students == null || getClass() != students.getClass())
        {
            return false;
        }

        Student otherStudents;
        otherStudents = (Student) students;

        return studentId.equals(otherStudents.studentId);
    }
}
