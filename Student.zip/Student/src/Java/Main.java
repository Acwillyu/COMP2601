public class Main
{
    public static void main(final String[] args)
    {
        Bcit bcit;
        bcit = new Bcit();

        Student student1;
        Student student2;

        student1 = new Student("David");
        student2 = new Student("David");

        bcit.register(student1);
        bcit.register(student2);

        if (student1.equals(student2))
        {
            System.out.println("These students are equal.");
        }
        else {
            System.out.println("These students are not equal.");
        }

    }
}
