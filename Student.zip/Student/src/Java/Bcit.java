public class Bcit extends School
{

    @Override
    public void register(final Student student)
    {
        students.add(student);
    }
}
