package ca.comp2601.bcit;
import java.util.Objects;
/**
 * Class for Ipad as an extension for IDevice.
 * @author William Yu, Ethan Newton, Erik Legman
 * @version 1.0
 */
public abstract class IPad extends IDevice
{
    // Instance Variables
    private final boolean hasCase;
    private final String osVersion;
    private static final int HASHCODE_ZERO = 0;

    /**
     * Constructor for IPad
     * @param hasCase   If the IPad has a case.
     * @param osVersion What version of the IPad is on.
     */
    public IPad(final boolean hasCase,
                final String osVersion)
    {
        super("learning");
        this.hasCase = hasCase;
        this.osVersion = osVersion;
    }

    /**
     * @return If IPad has a case.
     */
    public boolean isHasCase()
    {
        return hasCase;
    }

    /**
     * @return OS Version of the IPad.
     */
    public String getOsVersion()
    {
        return osVersion;
    }

    @Override
    public void printDetails()
    {
        System.out.println("Purpose: " + getPurpose());
        System.out.println("Has Case:" + hasCase);
        System.out.println("OS Version:" + osVersion );
    }

    @Override
    public boolean equals(Object obj)
    {
        IPad iPad;
        iPad = (IPad) obj;

        if (this == obj)
            return true;

        if (obj == null)
            return false;

        if (!super.equals(obj))
            return false;

        return isHasCase() == iPad.hasCase && Objects.equals(osVersion, iPad.getOsVersion());


    }

    @Override
    public int hashCode()
    {
        return Objects.hash(HASHCODE_ZERO);
    }



}
