package ca.comp2601.bcit;
import java.util.Objects;
/**
 * Class for IPod for an extension of IDevice.
 * @author William Yu, Ethan Newton, Erik Legman
 * @version 1.0
 */
public abstract class IPod extends IDevice
{
    //Instance Variables
    private final int    numSongs;
    private final double maxVolumeDecibles;
    private static final int HASHCODE_ZERO = 0;

    /**
     * IPod class constructor
     * @param numSongs  Number of songs on IPod.
     * @param maxVolume Max volume on IPod in decibles.
     */
    public IPod(final int numSongs,
                final double maxVolume)
    {
        super("music");
        this.numSongs = numSongs;
        this.maxVolumeDecibles = maxVolume;
    }

    /**
     * @return Number of songs on IPod.
     */
    public final int getNumSongs()
    {
        return numSongs;
    }

    /**
     * @return Max volume of IPod in decibles.
     */
    public final double getMaxVolume()
    {
        return maxVolumeDecibles;
    }

    @Override
    public void printDetails()
    {
        System.out.println("Purpose: " + getPurpose());
        System.out.println("Number of Songs: " + numSongs);
        System.out.println("Max Volume in Decibels: " + maxVolumeDecibles);
    }

    @Override
    public String toString()
    {
        return super.toString() + "Number of Songs" + numSongs + "Max Volume in Decibels" + maxVolumeDecibles;
    }

    @Override
    public boolean equals(Object obj)
    {
        IPod iPod;
        iPod = (IPod) obj;

        if (this == obj)
            return true;

        if (obj == null)
            return false;

        if (!super.equals(obj))
            return false;

        return Integer.valueOf(numSongs).equals(iPod.numSongs);

    }

    @Override
    public int hashCode()
    {
        return Objects.hash(HASHCODE_ZERO);
    }


}
