package ca.comp2601.bcit;
import java.util.Objects;
/**
 * Class for IPhoneSeven as an extension to the Iphone.
 * @author William Yu, Ethan Newton, Erik Legman
 * @version 1.0
 */
public class IPhoneSeven extends IPhone
{
    // Instance Variables
    private final boolean highResolutionCamera;
    private final int     memoryGigabytes;
    private static final int HASHCODE_ZERO = 0;

    /**
     * Constructor for IPhoneSeven
     * @param minutesRemaining     Remaining minutes on IPhoneSeven.
     * @param carrier              Carrier service for IPhoneSeven.
     * @param highResolutionCamera Determines if the IPhoneSeven has a high resolution camera.
     * @param memoryGigabytes      The amount of memory in the device.
     */
    public IPhoneSeven(double minutesRemaining,
                       String carrier,
                       boolean highResolutionCamera,
                       int memoryGigabytes)
    {
        super(minutesRemaining, carrier);
        this.highResolutionCamera = highResolutionCamera;
        this.memoryGigabytes      = memoryGigabytes;
    }

    /**
     * @return Determines if the phone has a high resolution camera. True or False.
     */
    public boolean isHighResolutionCamera()
    {
        return highResolutionCamera;
    }

    /**
     * @return Determines the memory of the device in gigabytes.
     */
    public int getMemoryGigabytes()
    {
        return memoryGigabytes;
    }


    @Override
    public boolean equals(Object obj)
    {
        final IPhoneSeven iPhoneSeven;
        iPhoneSeven = (IPhoneSeven) obj;

        if (this == obj)
            return true;

        if (obj == null)
            return false;

        if (!super.equals(obj))
            return false;

        return Double.valueOf(iPhoneSeven.getMinutesRemaining()).equals(getMinutesRemaining()) &&
                highResolutionCamera == iPhoneSeven.highResolutionCamera;
    }


    @Override
    public int hashCode()
    {
        return Objects.hash(HASHCODE_ZERO);
    }


}
