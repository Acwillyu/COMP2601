package ca.comp2601.bcit;
import java.util.Objects;

/**
 * Abstract parent class for apple I devices.
 * @author William Yu, Ethan Newton, Erik Legman
 * @version 1.0
 */
public abstract class IDevice
{
    // Instance Variable
    public String purpose;

    /**
     * Constructor of IDevice. Finds the purpose of the other devices.
     * @param purpose Purpose of the device.
     */
    public IDevice(final String purpose)
    {
        this.purpose = purpose;
    }

    /**
     * @return Purpose of other devices.
     */
    public final String getPurpose()
    {
        return purpose;
    }

    /**
     * Prints the details of the devices along with their purposes.
     */
    public abstract void printDetails();

    @Override
    public String toString()
    {
        return "Purpose: " + purpose;
    }

    @Override
    public boolean equals(Object obj)
    {
        IDevice iDevice;
        iDevice = (IDevice) obj;

        if(this == obj)
            return true;

        if(obj == null || getClass() != obj.getClass())
            return false;

        return Objects.equals(purpose, iDevice.purpose);
    }

    @Override
    public int hashCode()
    {
        return Objects.hash(purpose);
    }


}
