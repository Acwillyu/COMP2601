package ca.comp2601.bcit;
import java.util.Objects;
/**
 * Class for IPhone as an extension for IDevice
 * @author William Yu, Ethan Newton, Erik Legman
 * @version 1.0
 */
public abstract class IPhone extends IDevice
{
    // Instance variables
    private static double    minutesRemaining;
    private final  String    carrier;
    private static final int HASHCODE_ZERO = 0;

    /**
     * Constructor for Iphone
     * @param minutesRemaining Minutes the phone has left.
     * @param carrier          Carrier service of the IPhone.
     */
    public IPhone(final double minutesRemaining,
                  final String carrier)
    {
        super("talking");
        this.minutesRemaining = minutesRemaining;
        this.carrier = carrier;
    }
    /**
     * @return Remaining minutes on the IPhone.
     */
    public static double getMinutesRemaining()
    {
        return minutesRemaining;
    }

    /**
     * @return Carrier service of IPhone.
     */
    public String getCarrier()
    {
        return carrier;
    }

    @Override
    public void printDetails()
    {
        System.out.println("Purpose: " + getPurpose());
        System.out.println("Minutes Remaining: " + minutesRemaining);
        System.out.println("Carrier: " + carrier);
    }

    @Override
    public String toString()
    {
        return super.toString() + "Minutes remaining: " + minutesRemaining + "Carrier: " + carrier;
    }

    @Override
    public boolean equals(Object obj)
    {

        IPhone iPhone;
        iPhone = (IPhone) obj;

        if (this == obj)
            return true;

        if (obj == null)
            return false;

        if (!super.equals(obj))
            return false;

        return minutesRemaining == minutesRemaining && Objects.equals(carrier, iPhone.carrier);
    }

    @Override
    public int hashCode()
    {
        return Objects.hash(HASHCODE_ZERO);
    }


}

